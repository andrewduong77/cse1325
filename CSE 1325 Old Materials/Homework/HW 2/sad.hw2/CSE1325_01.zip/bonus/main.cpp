#include<iostream>
using namespace std;
#include "student.cpp"

int main()
{
	string name;
	int count=0;
	double grade;
	cout<<"Enter student's name: ";
	getline(cin,name);
	Student student{name};
	do
	{ cout<<"Enter next grade: ";
	  cin>>grade;
	  count++;
	  if(grade>=0)
	{student.exam(grade);
		}
		}
	while(grade>=0);
        do
	{ cout<<"Enter next hw grade: ";
	  cin>>grade;
	  count++;
	  if(grade>=0)
	{student.homework(grade);
		}
		}
	while(grade>=0);
	
	cout<<student.name()<<" has an average of"<<student.average()<<"\n";
}
