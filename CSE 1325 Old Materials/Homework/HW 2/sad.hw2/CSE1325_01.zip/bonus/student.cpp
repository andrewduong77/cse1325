#include <iostream>
using namespace std;

class Student{
  private:
	string student_name;
	double exam_sum;
	double exam_num_grades;
	double homework_sum;
	double homework_num_grades;
 public:
	Student(string name):student_name{name},exam_sum{0},exam_num_grades{0},homework_sum{0},homework_num_grades{0}{}
	
	
	string name(){return student_name;};
	void exam(double grade){
	exam_sum+=grade;
	exam_num_grades++;
	}
	void homework(double grade){
	homework_sum+=grade;
	homework_num_grades++;
	}
	double average()
	{
	  double avg;
	  double avg2;
	  if(exam_num_grades==0||homework_num_grades==0)
		return 100;
	  else
		{avg=(exam_sum)/(exam_num_grades);
		avg2=(homework_sum)/(homework_num_grades);}
	  
          return (avg*0.4)+(avg2*0.6);

	}
};
	
