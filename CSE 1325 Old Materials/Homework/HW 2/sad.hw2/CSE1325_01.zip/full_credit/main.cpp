#include<iostream>
using namespace std;
#include "student.cpp"

int main()
{
	string name;
	int count=0;
	double grade;
	cout<<"Enter student's name: ";
	getline(cin,name);
	Student student{name};
	do
	{ cout<<"Enter "<<count+1<<" grade: ";
	  cin>>grade;
	  count++;
	  if(grade>=0)
	{student.exam(grade);
		}
		}
	while(grade>=0);
	cout<<student.name()<<" has an average of"<<student.average()<<"\n";
}
