#include<iostream>
using namespace std;
#include "student.cpp"

int main()
{
  Student student {"Bjarne Stroustrup"};
  student.exam(100.0);
  student.exam(90.0);
  student.exam(80.0);
  if(student.name().compare("Bjarne Stroustrup")!=0)
    { cout<<"Name Error"<<endl;}
  if(student.average()!=90.0)
    cout<<"Avg error1"<<endl;
 
 Student nada {"Nope"};
 	if(nada.average()!=100.0)
    cout<<"Avg error2"<<endl;	
}	
	
