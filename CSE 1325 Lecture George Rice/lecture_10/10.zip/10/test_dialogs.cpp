#include <iostream>
#include <gtkmm.h>
#include "dialogs.h"

using namespace std;

int main(int argc, char *argv[])
{
    // Initialize GTK
    Gtk::Main kit(argc, argv);

    //
    // Test message dialog
    //
    Dialogs::message("This is a <b>test!</b>");

    Dialogs::message("<b>Bold</b>, <u>underlined</u>, and <span fgcolor='#ff0000'>Col</span>" 
        "<span fgcolor='#00ff00'>or</span> <span fgcolor='#0000ff'>ful</span> text!", "Testing 1 2 3");
    
    //
    // Test question dialog
    //
    cout << Dialogs::question("Is this OK?") << endl;

    vector<string> buttons = {"No", "Yes", "Guess So"};
    cout << Dialogs::question("Does this work?", "Report!", buttons) << endl;

    //
    // Test input
    //
    cout << Dialogs::input("What is your name?") << endl;

    cout << Dialogs::input("Where are you from?", "Better Question") << endl;

    cout << Dialogs::input("Who's your tailor?", "Best Question", "Franz Reichelt") << endl;

    cout << Dialogs::input("How's the styling?", "Select Cancel", "Rad", "Cancelled") << endl;

    //
    // Test image
    //
    Dialogs::image("moon.jpg", "Luna", "Or Selene if you're from ancient Greece");

    return EXIT_SUCCESS;
}
