#include <iostream>
using namespace std;

int x;	// global variable – avoid those where you can
int y;	// another global variable

int f() {
	int x;       // local variable (Note – now there are two x’s)
	x = 7;       // local x, not the global x
        int& rx = x;  // reference to outer scope x
        cout << "f's x = " << x << " but global x = " << ::x << endl;

        // A random scope just plopped into the program for no obvious reason
	{
		int x = y;  // another local x, initialized by the global y
                            // (Now there are three x’s)
                cout << "Before increment, nested x = " << x 
                     << ", while f's x = " << rx 
                     << ", while global x = " << ::x << endl;

		++x;	    // increment the local x in this scope

                cout << "After  increment, nested x = " << x 
                     << ", while f's x = " << rx 
                     << ", while global x = " << ::x << endl;
	}
        cout << "Now, f's x = " << x << " but global x = " << ::x << endl;
}

// avoid such complicated nesting and hiding: keep it simple!

int main() {
  cout << "global x = " << x << endl;
  f();
  cout << "global x = " << x << endl;
}
