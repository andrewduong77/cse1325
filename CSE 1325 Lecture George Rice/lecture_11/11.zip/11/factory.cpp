#include <iostream>
#include <vector>

using namespace std;

// The product interface
class Robot {
  public: 
    virtual void announce() = 0;
};

// The concrete product classes
class WalkingRobot : public Robot {
  public:
    void announce() override {
      cout << "Make way!" << endl;
    }
};

class FlyingRobot : public Robot {
  public:
    void announce() override {
      cout << "Heads up!" << endl;
    }
};

class DivingRobot : public Robot {
  public:
     void announce() override {
       cout << "Glub! Glub!" << endl;
     }
};

// The Creator interface
class RobotCreator {
  public:
    static Robot* getRobot(string criteria);
};

// The concrete creator (factory) class
class RobotFactory : public RobotCreator {
  public:
    static Robot* getRobot(string criteria) {
      if (criteria == "walks") 
        return new WalkingRobot();
      else if (criteria == "flies") 
        return new FlyingRobot();
      else
        return new DivingRobot();
    }
};

int main() {
    vector<string> criteria = {"walks", "flies", "dives"};
    for(string s: criteria) {
      Robot* robot = RobotFactory::getRobot(s);
      robot->announce();
    }
};
