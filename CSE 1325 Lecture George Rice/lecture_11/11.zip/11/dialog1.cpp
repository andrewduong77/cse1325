#include "dialogs.h"

int main(int argc, char *argv[]) {
    Gtk::Main kit(argc, argv);

    vector<string> buttons = {"Hello, World!"};
    std::cout << Dialogs::question("", "", buttons) << endl;
}

