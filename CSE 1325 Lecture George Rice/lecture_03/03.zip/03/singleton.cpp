#include <iostream> 

using namespace std;

// This is a non-Singleton class, with which to compare the Singleton below.
// It accepts a string in the constructor, then provides it via the to_string() method.

class Tester {
  private:
    string message;
  public:
    Tester(string text = "Default") : message{text} { }
    string to_string() {return message;}
};

// This is the Singleton class. Note that the constructor is PRIVATE and thus cannot
// be invoked by external code. Instead, the PUBLIC get_instance method calls the
// private constructor, both of which accept a string as parameter, saving the instance 
// as a static (permanent) variable of type Singleton and returning it. Any further calls
// to get_instance simply returns the same instance. As with Tester, this class offers
// a to_string method with which to recall the constructor's parameter.

class Singleton {
  private:
    string message;
    Singleton(string text = "Default") : message{text} { }
  public:
    static Singleton& get_instance(string text = "Default") {
      static Singleton instance{text};
      return instance;
    }
    string to_string() {return message;}
    Singleton(Singleton const&)      = delete;  // A C++ism. We'll cover it later.
    void operator=(Singleton const&) = delete;  // A C++ism. We'll cover it later.
};
    
int main(int argc, char *argv[]) {

  // Instance Tester to 3 reference variables, 
  // then print the address and message for each.

  Tester t1;
  Tester t2;
  Tester t3{"3 ftw!"};

  cout << "t1 is at " << &t1 << " and returns " << t1.to_string() << endl;
  cout << "t2 is at " << &t2 << " and returns " << t2.to_string() << endl;
  cout << "t3 is at " << &t3 << " and returns " << t3.to_string() << endl;

  // Instance Singleton to 3 reference variables, 
  // then print the address and message for each.

  Singleton& s1 = Singleton::get_instance("Hello, World!");
  Singleton& s2 = Singleton::get_instance("Goodbye, World!");
  Singleton& s3 = Singleton::get_instance();

  cout << "s1 is at " << &s1 << " and returns " << s1.to_string() << endl;
  cout << "s2 is at " << &s2 << " and returns " << s2.to_string() << endl;
  cout << "s3 is at " << &s3 << " and returns " << s3.to_string() << endl;

}


