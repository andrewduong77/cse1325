#include <iostream>  // for cin and cout
#include <vector>    // for vector
#include <algorithm> // for sort
using namespace std;

// compute mean (average) and median temperatures:
int main()
{

    // Declare a vector "temps" that can hold any number of double values
    // and a temp buffer to hold incoming data.

    vector<double> temps;	 // temperatures in Fahrenheit, e.g. 64.6
    double temp;

    // Loop, accepting new temperatures, until the user enters "end" or
    // presses End of File (control-d for Linux and Mac, control-z for Windows)

    cout << "Enter a series of temperatures, followed by 'end':" << endl;
    while (cin>>temp)
        temps.push_back(temp); // read and put into vector

    // Calculate the sum of the temperatures collected.

    double sum = 0;
    for (int i = 0; i<temps.size(); ++i) sum += temps[i];  // sums temperatures

    // Calculate and report the mean (average) temperature.
    // temps.size() is a METHOD of the OBJECT temps that returns the number
    // of elements that temps currently contains.

    cout << "Mean temperature: " << sum/temps.size() << endl;

    // Sort (a function) sorts the temps vector in place (it actually changes it,
    // rather than creating a new changed copy). Once sorted, report the median
    // (middle) of the series of temperatures collected in the temps vector.

    sort(temps.begin(), temps.end());	
    cout << "Median temperature: " << temps[temps.size()/2] << endl;
}

