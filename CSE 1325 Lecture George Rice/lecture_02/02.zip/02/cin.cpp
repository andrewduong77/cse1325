#include <string>
#include <iostream>
using namespace std;

int main() {
  string s1;
  cout << "Enter your name (including spaces): ";
  cin >> s1;
  cout << "Your name is " << s1 << endl;
}
