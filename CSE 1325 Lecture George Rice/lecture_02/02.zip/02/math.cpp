 #include <iostream>
 using namespace std;
 int main() {
   while(1) {
     cout << "Enter two integers: ";
     int num1, num2;
     cin >> num1 >> num2;
     cout << "The sum        is "<< num1 + num2 << endl;
     cout << "The difference is "<< num1 - num2 << endl;
     cout << "The product    is "<< num1 * num2 << endl;
   }
   return 0;
 }
