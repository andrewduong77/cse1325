 #include <iostream>
 #include "traffic_light.cpp"
 using namespace std;


 int main() {
   Traffic_light Cooper_and_UTA;
   Cooper_and_UTA.turn_on();
   for (int i = 0; i < 10; ++i) {
      Cooper_and_UTA.next_color();
      cout << "Traffic light is " << 
       Cooper_and_UTA.string_color() 
       << endl;
   }
 }
