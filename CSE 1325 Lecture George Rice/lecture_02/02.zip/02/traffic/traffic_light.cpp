 #include <string>
 using namespace std;

 enum Color {green, yellow, red};
 class Traffic_light {
   private:
     bool operating = false;
     Color light = red;
   public:
     bool is_operating() {return operating;}
     void turn_on() {operating = true;}
     void turn_off() {operating = false;}
     Color this_color() {return light;}
     Color next_color() {
       light = (light == green) ? yellow :
               (light == yellow) ? red : green;
       return light;
     }
     string string_color() {
         return (light == green) ? "green" :
                (light == yellow) ? "yellow" : "red";
     }
 };
