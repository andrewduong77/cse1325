#include "coordinate.h"
#include <iostream>
#include <string>

using namespace std;

/**
 * Test Coordinate
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
int main() {
  string expected = "(0,0)  (0,3)  (0,6)  (2,0)  (2,3)  (2,6)  (4,0)  (4,3)  (4,6)  ";
  string actual = "";
  for(int x = 0; x < 3; ++x) {
    for(int y = 0; y < 3; ++y) {
      Coordinate c(x*2, y*3);
      actual += '(' + to_string(c.get_x()) + ',' + to_string(c.get_y()) + ")  ";
    }
  }

  if (expected != actual) {
    cerr << "fail: coordinate.h: static initialization" << endl;
    cerr << "expected: \"" << expected << "\"" << endl;
    cerr << "actual:   \"" << actual << "\"" << endl << endl;
    return -1;
  }


  srand(0xbadcafe);
  expected = "(20,26)  (10,3)  (22,21)  (7,19)  (5,17)  (2,13)  (12,24)  (18,18)  (22,12)  ";
  actual = "";
  for(int i = 0; i < 9; ++i) {
    Coordinate c;
    actual += '(' + to_string(c.get_x()) + ',' + to_string(c.get_y()) + ")  ";
  }

  if (expected != actual) {
    cerr << "fail: coordinate.h: random initialization" << endl;
    cerr << "expected: \"" << expected << "\"" << endl;
    cerr << "actual:   \"" << actual << "\"" << endl << endl;
    return -1;
  }

  return 0;
}
