#include "evaluator.h"
#include "globals.h"
#include <iostream>

using namespace std;

Evaluator::Evaluator(int argc, char* argv[]) : _expected{""} {
 if (argc == 1) {
    _mode = evaluate;
  } else if ((argc == 2) && (string(argv[1]) == "-v")) {
    _mode = generate_output;
  }
}

void Evaluator::load_expected(string test_description) {
  _expected = "";
  string aline;
  for (int i=0; i < MAX_Y; ++i) {
     if (!getline(cin, aline)) {
       cerr << "ERROR: Insufficient expected lines for " << test_description << endl;
       exit(-2);
     }
     _expected += aline + '\n';
  }
  getline(cin, aline); // delete the separator \n
}

void Evaluator::evaluate_test(string test_description, string actual) {
  if (_mode == evaluate) {
    load_expected(test_description);
    if (_expected != actual) {
      cerr << "fail: grid.h: " + test_description << endl;
      cerr << "expected: \"" << _expected << "\"" << endl;
      cerr << "actual:   \"" << actual << "\"" << endl << endl;
      exit(-1);
    }
  }
  else if (_mode == generate_output) {
    cout << actual << endl;
  } else {
    cerr << "ERROR: Invalid parameters" << endl;
    exit(-1);
  }
}

string Evaluator::get_expected() {
  return _expected;
}

