#include <string>

using namespace std;

class Evaluator {
  public:
    Evaluator(int argc, char* argv[]);            // Sets the mode based on parameters
    void evaluate_test(string test_description, 
                       string actual);            // Load and compare expected to actual
    string get_expected();                        // Return expected
  private:
    void load_expected(string test_description);  // read _expected string from stdin
    string _expected;
    enum Mode {generate_output, evaluate, error};
    Mode _mode = error;

};

