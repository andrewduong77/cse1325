#include "globals.h"
#include "grid.h"
#include "coordinate.h"
#include "evaluator.h"
#include <string>

using namespace std;

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */

int main(int argc, char* argv[]) {
  srand(0xbadcafe);
  Evaluator eval{argc, argv};

  //
  // Test #1 - Default initialization
  //
  Grid grid{};
  eval.evaluate_test("Default initialization", grid.to_string( ));

  grid = Grid{33};
  eval.evaluate_test("Initialize to 33 robots", grid.to_string( ));

  grid = Grid{Coordinate{0, 0}};
  grid.move_player(Coordinate{-1, -1});
  eval.evaluate_test("Move off upper left of grid", grid.to_string( ));

  grid = Grid{Coordinate{MAX_X-1, MAX_Y-1}};
  grid.move_player(Coordinate{1, 1});
  eval.evaluate_test("Move off lower right of grid", grid.to_string( ));
}
