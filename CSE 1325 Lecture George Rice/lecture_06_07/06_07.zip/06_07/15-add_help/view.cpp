#include "view.h"
#include <iostream>

/**
 * View displays the grid on a text terminal
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
void View::print_banner() {
    cout << "============" << endl
         << "ROVING ROBOT" << endl
         << "============" << endl << endl;
}

Grid View::get_grid() {return grid;}
void View::print_grid() {
  cout << endl;
  cout << grid.to_string() << endl;
};
 
void View::print_help() {
  cout << "Use the numeric keypad to maneuver your robot (R)" << endl
       << " and avoid the drones (X)." << endl
       << endl
       << "You may take one step in any direction:" << endl
       << "            7  8  9" << endl
       << "             \\ | /" << endl
       << "            4--5--6" << endl
       << "             / | \\" << endl
       << "            1  2  3" << endl
       << "        exit--0  .--teleport " << endl 
       << endl
       << "The drones will always take one step toward you." << endl
       << "Collisions destroy those involved, and leave behind" << endl
       << "a lethal debris field (*). Good luck!" << endl << endl;
}
