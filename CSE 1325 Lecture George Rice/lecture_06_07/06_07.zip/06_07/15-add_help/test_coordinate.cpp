 #include "std_lib_facilities.h"
 #include "coordinate.h"

/**
 * Test Coordinate
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
int main() {
  cout << "Test Coodrinate using explicit constructors" << endl;
  cout << "(0,0)  (0,3)  (0,6)  (2,0)  (2,3)  (2,6)  (4,0)  (4,3)  (4,6)" << endl;
  for(int x = 0; x < 3; ++x) {
    for(int y = 0; y < 3; ++y) {
      Coordinate c(x*2, y*3);
      cout << c.to_string() << "  ";
    }
  }
  cout << endl << endl;

   cout << "Test using random constructors (value may change on recompile)" << endl;
   cout << "(7,1)  (7,0)  (7,5)  (3,1)  (1,6)  (4,5)  (7,5)  (4,5)  (0,6)  (1,7)" << endl;
   for(int i = 0; i < 10; ++i) {
     Coordinate c;
     cout << c.to_string() << "  ";
   }
   cout << endl;

  return 0;
}
