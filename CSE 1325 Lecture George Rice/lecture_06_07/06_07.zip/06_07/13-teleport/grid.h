#ifndef GRID
#define  GRID 2017

#include "robot.h"
#include <vector>

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class Grid {
  public:
    Grid(int num_robots, Coordinate ralphs_coord) 
        : _player{Robot{"Ralph", ralphs_coord}}  { 
      for (int i=0; i < num_robots; ++i)
        _robots.push_back(Robot{});
    }
    Grid(int num_robots) : Grid(num_robots, Coordinate{MAX_X/2, MAX_Y/2}) { }
    Grid(Coordinate ralphs_coord) : Grid(NUM_ROBOTS, ralphs_coord) { } 
    Grid() : Grid(NUM_ROBOTS) { }

    Robot get_player( );
    void move_player(Coordinate direction);

    int get_num_robots();
    Robot get_robot(int robot_id);
    void move_robot(int robot_id, Coordinate direction);
    void detect_collisions( );
    void animate_robots( );
    void teleport( );

    string to_string( );

  private:
    Robot _player; // The robot controlled by the player
    vector<Robot> _robots; // The robots wandering the grid
};
#endif 
