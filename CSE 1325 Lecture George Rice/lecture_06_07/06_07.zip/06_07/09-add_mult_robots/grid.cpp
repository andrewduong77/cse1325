 #include "grid.h"
 #include "globals.h"
 #include "robot.h"

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
Robot Grid::get_player( ) {return _player;}
void Grid::move_player(Coordinate direction) {
    _player.move(direction);
}

int Grid::get_num_robots() {return _robots.size(); }
Robot Grid::get_robot(int robot_id) {return _robots[robot_id];}
void Grid::move_robot(int robot_id, Coordinate direction) {_robots[robot_id].move(direction);}

string Grid::to_string() {
  string grid = "";
  for (int y = 0; y < MAX_Y; ++y) {
    for (int x = 0; x < MAX_X; ++x) {
      char this_pos = '.';
      for(int i=0; i<_robots.size(); ++i) {
        if (x == _robots[i].get_coordinate().get_x() &&
            y == _robots[i].get_coordinate().get_y())
          this_pos = 'X';
      }
      if (x == _player.get_coordinate().get_x() &&
          y == _player.get_coordinate().get_y())
         this_pos = 'R';
      grid += this_pos;
    }
    grid += '\n';
  }
  return grid;
}
