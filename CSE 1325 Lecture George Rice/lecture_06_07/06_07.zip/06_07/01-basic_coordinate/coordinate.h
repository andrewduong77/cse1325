#ifndef COORDINATE_H
#define COORDINATE_H 2017
/**
 * Coordinate models a location on a 2D grid.
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class Coordinate {
  public:
    Coordinate(int x, int y) : _x{x}, _y{y} { }
    int get_x();
    int get_y();
  private:
    int _x;
    int _y;
};
#endif
