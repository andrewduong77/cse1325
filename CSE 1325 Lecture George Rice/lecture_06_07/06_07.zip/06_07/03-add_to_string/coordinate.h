#ifndef COORDINATE_H
#define COORDINATE_H 2017
#include "globals.h"
#include <stdlib.h>
#include <string>
using namespace std;

/**
 * Coordinate models a location on a 2D grid.
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class Coordinate {
  public:
    Coordinate() : Coordinate(rand() % MAX_X, rand() % MAX_Y) { }
    Coordinate(int x, int y) : _x{x}, _y{y} { }
    int get_x();
    int get_y();
    string to_string();
  private:
    int _x;
    int _y;
};
#endif

