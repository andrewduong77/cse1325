#ifndef VIEW
#define  VIEW 2017

#include "grid.h"

/**
 * View displays the grid on a text terminal
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class View {
  public:
    // View(Grid& g) : grid{g} {};
    View(Grid& g) : grid(g) {};

    void print_banner();
    Grid get_grid();
    void print_grid();

  private:
    Grid& grid; // The grid containing the wandering robot

};
#endif 
