 #include "grid.h"
 #include "globals.h"
 #include "robot.h"

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
Robot Grid::get_player( ) {return _player;}
void Grid::move_player(Coordinate direction) {
    _player.move(direction);
}

int Grid::get_num_robots() {return _robots.size(); }
Robot Grid::get_robot(int robot_id) {return _robots[robot_id];}
void Grid::move_robot(int robot_id, Coordinate direction) {_robots[robot_id].move(direction);}
void Grid::teleport( ) {_player = Robot{ };}

void Grid::animate_robots( ) {
  for (Robot& robot : _robots) {
    if (robot.is_alive()) {
      int delta_x = robot.get_coordinate().get_x() - 
                    _player.get_coordinate().get_x();
      int delta_y = robot.get_coordinate().get_y() - 
                    _player.get_coordinate().get_y();
      robot.move(Coordinate(delta_x < 0 ? 1 : (delta_x > 0 ? -1 : 0),
                            delta_y < 0 ? 1 : (delta_y > 0 ? -1 : 0)));
    }
  }
}

void Grid::detect_collisions( ) {
  for (int i=0; i<_robots.size(); ++i) {
    if (_player.get_coordinate().get_x() == _robots[i].get_coordinate().get_x() &&
        _player.get_coordinate().get_y() == _robots[i].get_coordinate().get_y()) {
      _player.kill();
      _robots[i].kill();
    }
    for (int j=i+1; j<_robots.size(); ++j) {
      if (_robots[j].get_coordinate().get_x() == _robots[i].get_coordinate().get_x() &&
          _robots[j].get_coordinate().get_y() == _robots[i].get_coordinate().get_y()) {
        _robots[j].kill();
        _robots[i].kill();
      }
    }
  }
}

bool Grid::any_robots_alive( ) {
  for (Robot robot: _robots) {
    if (robot.is_alive()) return true;
  }
  return false;
}

string Grid::to_string() {
  string grid = "";
  for (int y = 0; y < MAX_Y; ++y) {
    for (int x = 0; x < MAX_X; ++x) {
      char this_pos = '.';
      for(int i=0; i<_robots.size(); ++i) {
        if (x == _robots[i].get_coordinate().get_x() &&
            y == _robots[i].get_coordinate().get_y())
          this_pos = _robots[i].is_alive() ? 'X' : '*';
      }
      if (x == _player.get_coordinate().get_x() &&
          y == _player.get_coordinate().get_y())
         this_pos = _player.is_alive() ? 'R' : '*';
      grid += this_pos;
    }
    grid += '\n';
  }
  return grid;
}

