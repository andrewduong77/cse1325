#ifndef GRID
#define  GRID 2017

#include "robot.h"
#include <vector>

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class Grid {
  public:
    Grid(int num_robots) { 
      srand(time(NULL)); // seed rand()
      for (int i=0; i < num_robots; ++i)
        _robots.push_back(Robot{});
    }
    Grid() : Grid(NUM_ROBOTS) { }

    Robot get_player( );
    void move_player(Coordinate direction);

    int get_num_robots();
    Robot get_robot(int robot_id);
    void move_robot(int robot_id, Coordinate direction);
    void detect_collisions( );
    void animate_robots( );

    string to_string( );

  private:
    // Robot _player{"Ralph", Coordinate{MAX_X/2, MAX_Y/2}}; // The robot controlled by the player
    Robot _player{"Ralph", Coordinate{28, 28}}; // TODO: Just for quick testing
    vector<Robot> _robots; // The robots wandering the grid
};
#endif 
