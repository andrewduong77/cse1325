#include "grid.h"
#include "robot.h"

/**
 * Controller manages the model and view
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class Controller {
  public:
    void cli();
    void execute_cmd(string cmd);

  private:
    Robot _player;
    Grid grid{_player};

};
 
