 #include "grid.h"
 #include "globals.h"
 #include "robot.h"

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
Robot Grid::get_player( ) {return _player;}
void Grid::move_player(Coordinate direction) {
    _player.move(direction);
}
string Grid::to_string() {
    string grid = "";
    for (int x = 0; x < MAX_X; ++x) {
      for (int y = 0; y < MAX_Y; ++y) {
        grid += (x == _player.get_coordinate().get_x() && 
                 y == _player.get_coordinate().get_y()) ? "R" : ".";
      }
      grid += '\n';
    }
    return grid;
}
