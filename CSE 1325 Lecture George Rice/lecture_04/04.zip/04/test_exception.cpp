#include <exception>
#include <iostream>
using namespace std;

class newx: exception { } myx;

int main() {
  try {
    throw myx;
  } catch (exception& e) {
    cout << e.what() << endl;
  }
}
