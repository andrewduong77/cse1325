 #include <iostream>
 #include <exception>
 using namespace std;

 class Bad_area: public exception { };

 int area(int length, int width) {
   if (length<=0 || width<=0) throw Bad_area{ };   // note the {} – a value
   return length*width;
 }
 int main() {
   try {
     cout << area(3, 5) << endl;
     cout << area(8, 2) << endl;
     cout << area(3,-5) << endl;
     return 0; // success
   } catch(Bad_area e) {
     cerr << "Bad area call - fix program!" << endl;
     return 1; // failure
   }
 }

