#include "and7697_Librarian.h"

void Librarian::check_out()
{

}

void Librarian::check_in()
{

}

string Librarian::get_name()
{
    return name;
}

int Librarian::get_id()
{
    return id;
}

void Librarian::set_type(string type)
{
    this->type = type;
}

string Librarian::get_type()
{
    return type;
}
