#include "and7697_Transaction.h"

double Transaction::calculate_fee()
{

}
